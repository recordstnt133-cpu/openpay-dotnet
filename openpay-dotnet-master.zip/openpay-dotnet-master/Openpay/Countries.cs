namespace Openpay
{
    public enum Countries
    {
        MX,
        PE,
        CO
    }
}