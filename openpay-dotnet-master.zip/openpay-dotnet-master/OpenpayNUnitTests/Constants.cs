﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OpenpayNUnitTests
{
    public static class Constants
    {
        public static string API_KEY = "sk_d5a90a83ee78483890286e2dfb61dd35";
        public static string MERCHANT_ID = "mwfxtxcoom7dh47pcds1";
		// public static string NEW_API_KEY = "sk_440e7370f8f34ed592463a452d122a4c";
		// public static string NEW_MERCHANT_ID = "mexzhpxok3houd5lbvz1";
		public static string NEW_API_KEY = "sk_f934dfe51645483e82106301d985a4f6";
		public static string NEW_MERCHANT_ID = "m3cji4ughukthjcsglv0";
		// https://sandbox-api.openpay.pe/v1/m3cji4ughukthjcsglv0/customers?limit=10&offset=0

		public static string PublicIp = "138.84.62.109";

		public static string API_KEY_CO = "";
		public static string MERCHANT_ID_CO = "";
    }
}
